import App from "./App";
export * from "./App";

export default App;
